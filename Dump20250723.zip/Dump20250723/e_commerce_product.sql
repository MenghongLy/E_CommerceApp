-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: localhost    Database: e_commerce
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product` (
  `P_ID` int NOT NULL,
  `Name` varchar(255) DEFAULT NULL,
  `Price` decimal(10,2) DEFAULT NULL,
  `Description` text,
  PRIMARY KEY (`P_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES (1,'Chanel No. 5 Eau de Parfum',125.00,'The iconic floral aldehyde fragrance with notes of ylang-ylang, rose, lily of the valley, iris, and vetiver. A timeless classic that epitomizes elegance and femininity. 100ml bottle.'),(2,'Dior Sauvage Eau de Toilette',95.00,'A fresh and raw fragrance inspired by wide-open spaces. Features bergamot, pepper, ambroxan, and patchouli. Perfect for the modern man seeking adventure. 100ml bottle.'),(3,'Tom Ford Black Orchid',180.00,'A luxurious and sensual unisex fragrance with black orchid, spice, dark chocolate, and patchouli. Rich and sophisticated scent for evening wear. 50ml bottle.'),(4,'Giorgio Armani Acqua di Gio',85.00,'A fresh aquatic fragrance inspired by the Mediterranean sea. Contains marine notes, bergamot, neroli, and cedar. Light and refreshing for daily wear. 100ml bottle.'),(5,'Yves Saint Laurent Black Opium',110.00,'An addictive gourmand fragrance with coffee, vanilla, white flowers, and cedar. Bold and mysterious scent for confident women. 90ml bottle.'),(6,'Creed Aventus',350.00,'A sophisticated blend of pineapple, birch, musk, and oakmoss. Inspired by Napoleon\'s dramatic life. Premium niche fragrance for discerning individuals. 120ml bottle.'),(7,'Versace Eros Eau de Toilette',75.00,'A passionate fragrance with mint, green apple, tonka bean, and vanilla. Inspired by Greek mythology and divine love. Vibrant and energetic scent. 100ml bottle.'),(8,'Maison Francis Kurkdjian Baccarat Rouge 540',285.00,'A luminous and sophisticated scent with saffron, amberwood, and cedar. Crystal clear and radiant fragrance that captivates the senses. 70ml bottle.'),(9,'Dolce & Gabbana Light Blue',70.00,'A Mediterranean-inspired fragrance with Sicilian lemon, apple, bamboo, and cedar. Fresh and spontaneous scent perfect for summer days. 100ml bottle.'),(10,'Viktor & Rolf Flowerbomb',135.00,'An explosive floral bouquet with orchid, rose, freesia, and patchouli. A powerful and feminine fragrance that makes a statement. 100ml bottle.');
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-23 21:53:15
